<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\AppBaseController as Controller;


class SalesController extends Controller
{

}
