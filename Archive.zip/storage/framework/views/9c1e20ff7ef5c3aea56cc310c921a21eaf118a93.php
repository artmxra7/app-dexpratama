<li class="<?php echo e(Request::is('newsCategories*') ? 'active' : ''); ?>">
    <a href="<?php echo route('newsCategories.index'); ?>"><i class="fa fa-edit"></i><span>News Categories</span></a>
</li>

<li class="<?php echo e(Request::is('news') || Request::is('news/*') ? 'active' : ''); ?>">
    <a href="<?php echo route('news.index'); ?>"><i class="fa fa-edit"></i><span>News</span></a>
</li>

<li class="<?php echo e(Request::is('productBrands*') ? 'active' : ''); ?>">
    <a href="<?php echo route('productBrands.index'); ?>"><i class="fa fa-edit"></i><span>Product Brands</span></a>
</li>

<li class="<?php echo e(Request::is('productUnitModels*') ? 'active' : ''); ?>">
    <a href="<?php echo route('productUnitModels.index'); ?>"><i class="fa fa-edit"></i><span>Product Unit Models</span></a>
</li>

<li class="<?php echo e(Request::is('products*') ? 'active' : ''); ?>">
    <a href="<?php echo route('products.index'); ?>"><i class="fa fa-edit"></i><span>Products</span></a>
</li>

<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('users.index'); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="<?php echo e(Request::is('coupons*') ? 'active' : ''); ?>">
    <a href="<?php echo route('coupons.index'); ?>"><i class="fa fa-edit"></i><span>Coupons</span></a>
</li>

<li class="<?php echo e(Request::is('order_sparepart*') ? 'active' : ''); ?>">
    <a href="<?php echo route('order_sparepart.index'); ?>"><i class="fa fa-edit"></i><span>Order Products</span></a>
</li>

<li class="<?php echo e(Request::is('order_job*') ? 'active' : ''); ?>">
    <a href="<?php echo route('order_job.index'); ?>"><i class="fa fa-edit"></i><span>Order Job</span></a>
</li>

<li class="<?php echo e(Request::is('job_categories*') ? 'active' : ''); ?>">
    <a href="<?php echo route('job_categories.index'); ?>"><i class="fa fa-edit"></i><span>Job Categories</span></a>
</li>

<li class="<?php echo e(Request::is('commission_sales*') ? 'active' : ''); ?>">
    <a href="<?php echo route('commission_sales.index'); ?>"><i class="fa fa-edit"></i><span>Commission Sales</span></a>
</li>

<li class="<?php echo e(Request::is('commission_mechanic*') ? 'active' : ''); ?>">
    <a href="<?php echo route('commission_mechanic.index'); ?>"><i class="fa fa-edit"></i><span>Commission Mechanic</span></a>
</li>

<li class="<?php echo e(Request::is('settings*') ? 'active' : ''); ?>">
    <a href="<?php echo route('settings.index'); ?>"><i class="fa fa-edit"></i><span>Settings</span></a>
</li>
