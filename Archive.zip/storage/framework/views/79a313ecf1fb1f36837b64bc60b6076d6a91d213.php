<?php if($role == 'member'): ?>
  customer
<?php else: ?>
  <?php echo e($role); ?>

<?php endif; ?>
