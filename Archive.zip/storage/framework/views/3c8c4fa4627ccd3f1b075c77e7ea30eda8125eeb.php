<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $users->id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $users->name; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $users->email; ?></p>
</div>

<!-- Phone Field -->
<div class="form-group">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <p><?php echo $users->phone; ?></p>
</div>

<!-- Address Field -->
<div class="form-group">
    <?php echo Form::label('address', 'Address:'); ?>

    <p><?php echo $users->address; ?></p>
</div>

<!-- Role Field -->
<div class="form-group">
    <?php echo Form::label('role', 'Role:'); ?>

    <p>
      <?php if($users->role == 'member'): ?>
      customer
      <?php else: ?>
      <?php echo $users->role; ?>

      <?php endif; ?>
    </p>
</div>

<!-- City Field -->
<div class="form-group">
    <?php echo Form::label('city', 'City:'); ?>

    <p><?php echo $users->city; ?></p>
</div>
