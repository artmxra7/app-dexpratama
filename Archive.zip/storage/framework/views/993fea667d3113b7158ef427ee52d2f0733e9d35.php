<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => true]); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control', 'required' => true]); ?>

</div>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Password:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Password Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password_confirmation', 'Password Confirmation:'); ?>

    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>


<!-- Role Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('role', 'Role:'); ?>

    <?php echo Form::select('role', ['member' => 'customer','sales'=> 'sales', 'mechanic'=>'mechanic','admin' => 'admin'], null, ['class' => 'form-control', 'required' => true, 'placeholder' => '--Choose one--']); ?>

</div>

<!-- Address Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('address', 'Address:'); ?>

    <?php echo Form::textarea('address', null, ['class' => 'form-control', 'rows' => 3]); ?>

</div>

<!-- City Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('city', 'City:'); ?>

    <?php echo Form::select('city', [], null, ['class' => 'form-control', 'required' => true]); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('users.index'); ?>" class="btn btn-default">Cancel</a>
</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        $.getJSON('<?php echo e(url('storage/cities.json')); ?>', function(json, textStatus) {
            $('#city').select2({
                data: json,
                placeholder: '--Choose One--'
            })

            $('#city').val('<?php echo e(isset($user) ? $user->city : null); ?>').trigger('change')
        });
    </script>
<?php $__env->stopSection(); ?>
