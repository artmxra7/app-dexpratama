<?php if($user_sales_name == '-'): ?>
    <?php echo e($user_sales_name); ?>

<?php else: ?>
    <a href="<?php echo e(route('users.show', $user_sales_id)); ?>"><?php echo e($user_sales_name); ?></a>
<?php endif; ?>
