<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $product->id; ?></p>
</div>

<!-- Title Field -->
<div class="form-group">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo $product->title; ?></p>
</div>

<!-- Slug Field -->
<div class="form-group">
    <?php echo Form::label('slug', 'Slug:'); ?>

    <p><?php echo $product->slug; ?></p>
</div>

<!-- No Product Field -->
<div class="form-group">
    <?php echo Form::label('no_product', 'No Product:'); ?>

    <p><?php echo $product->no_product; ?></p>
</div>

<!-- Sn Product Field -->
<div class="form-group">
    <?php echo Form::label('sn_product', 'Sn Product:'); ?>

    <p><?php echo $product->sn_product; ?></p>
</div>

<!-- Photo Field -->
<div class="form-group">
    <?php echo Form::label('photo', 'Photo:'); ?>

    <?php 
        if (isset($product)) {
            $photo = explode(',', $product->photo);
        }
     ?>
    <div class="photo-list">
        <div class="photo-item">
            <?php if(isset($photo[0])): ?>
                <img src="<?php echo e(url('attachments/products/' . $photo[0])); ?>" class="photo" />
            <?php else: ?>
                <img src="" class="photo" />
            <?php endif; ?>
        </div>
        <div class="photo-item">
            <?php if(isset($photo[1])): ?>
                <img src="<?php echo e(url('attachments/products/' . $photo[1])); ?>" class="photo" />
            <?php else: ?>
                <img src="" class="photo" />
            <?php endif; ?>
        </div>
        <div class="photo-item">
            <?php if(isset($photo[2])): ?>
                <img src="<?php echo e(url('attachments/products/' . $photo[2])); ?>" class="photo" />
            <?php else: ?>
                <img src="" class="photo" />
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Description Field -->
<div class="form-group">
    <?php echo Form::label('description', 'Description:'); ?>

    <p><?php echo $product->description; ?></p>
</div>

<!-- Price Piece Field -->
<div class="form-group">
    <?php echo Form::label('price_piece', 'Price Piece:'); ?>

    <p><?php echo $product->price_piece; ?></p>
</div>

<!-- Price Box Field -->
<div class="form-group">
    <?php echo Form::label('price_box', 'Price Box:'); ?>

    <p><?php echo $product->price_box; ?></p>
</div>

<!-- Is Active Field -->
<div class="form-group">
    <?php echo Form::label('is_active', 'Is Active:'); ?>

    <p><?php echo $product->is_active; ?></p>
</div>

<!-- Product Unit Model Id Field -->
<div class="form-group">
    <?php echo Form::label('product_unit_model_id', 'Product Unit Model Id:'); ?>

    <p><?php echo $product->product_unit_model_id; ?></p>
</div>

<!-- Product Brand Id Field -->
<div class="form-group">
    <?php echo Form::label('product_brand_id', 'Product Brand Id:'); ?>

    <p><?php echo $product->product_brand_id; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $product->deleted_at; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $product->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $product->updated_at; ?></p>
</div>
