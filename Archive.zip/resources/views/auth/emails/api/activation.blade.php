<p>Selamat bergabung menjadi anggota dari Dextra Services. Untuk melakukan aktifasi akun silahkan masukkan kode berikut: {{ $code }}</p>
<p>Buka kembali aplikasi Dextra Services dan masukkan kode tersebut melalui halaman Aktifasi akun yang telah tersedia.</p>
